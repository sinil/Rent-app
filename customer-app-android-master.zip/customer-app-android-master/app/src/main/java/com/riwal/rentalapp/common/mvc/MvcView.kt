package com.riwal.rentalapp.common.mvc

interface MvcView {

    fun notifyDataChanged()

}