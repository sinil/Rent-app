package com.riwal.rentalapp

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

@GlideModule
class RiwalRentalGlideModule : AppGlideModule()