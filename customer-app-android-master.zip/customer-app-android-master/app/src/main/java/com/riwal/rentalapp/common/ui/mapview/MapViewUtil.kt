package com.riwal.rentalapp.common.ui.mapview

fun MapView.zoomToShowAllClusterItems() = zoomToShowClusterItems(clusterItems)