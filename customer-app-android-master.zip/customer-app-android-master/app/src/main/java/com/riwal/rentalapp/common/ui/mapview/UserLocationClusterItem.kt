package com.riwal.rentalapp.common.ui.mapview

import com.google.android.gms.maps.model.LatLng

class UserLocationClusterItem(position: LatLng) : ClusterItem(title = "", position = position)