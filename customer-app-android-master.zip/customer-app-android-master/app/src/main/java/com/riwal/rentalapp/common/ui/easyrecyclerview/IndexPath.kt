package com.riwal.rentalapp.common.ui.easyrecyclerview

/**
 * Created by emiel on 31-03-17.
 */

data class IndexPath(val row: Int, val section: Int)
