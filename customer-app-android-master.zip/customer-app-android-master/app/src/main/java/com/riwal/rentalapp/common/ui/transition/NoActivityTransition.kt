package com.riwal.rentalapp.common.ui.transition

object NoActivityTransition : BasicActivityTransition(enterAnimationRes = 0, exitAnimationRes = 0)