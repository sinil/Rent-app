package com.riwal.rentalapp.model.api

data class LoginBody(val userName: String, val password: String)