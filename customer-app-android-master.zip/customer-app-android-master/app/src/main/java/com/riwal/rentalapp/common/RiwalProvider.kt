package com.riwal.rentalapp.common

import androidx.core.content.FileProvider

class RiwalProvider: FileProvider() {
}