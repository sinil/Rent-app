package com.riwal.rentalapp.helpmechoose

enum class ReachType {
    NOT_SPECIFIED,
    VERTICAL,
    ANGLED,
    MULTI_ANGLED
}
