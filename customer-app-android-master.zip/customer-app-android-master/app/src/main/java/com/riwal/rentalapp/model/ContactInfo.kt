package com.riwal.rentalapp.model

data class ContactInfo(val name: String, val phoneNumber: String, val email: String?)