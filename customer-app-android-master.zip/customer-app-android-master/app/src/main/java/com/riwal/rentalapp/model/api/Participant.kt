package com.riwal.rentalapp.model.api

data class Participant(val Maximum: Int,
                       val Minimum: Int,
                       val StringValue: String)
