package com.riwal.rentalapp.model

data class Place(val address: String, var coordinate: Coordinate)