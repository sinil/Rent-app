package com.riwal.rentalapp.model.api

data class TrainingDepot(
        val Id: String,
        val Name: String,
        val EmailId: String
)