package com.riwal.rentalapp.project.editproject

enum class EditProjectStyle {
    CREATE,
    EDIT
}