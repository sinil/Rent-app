package com.riwal.rentalapp.common.ui.transition

import androidx.annotation.AnimRes

open class BasicActivityTransition(@AnimRes val enterAnimationRes: Int, @AnimRes val exitAnimationRes: Int)