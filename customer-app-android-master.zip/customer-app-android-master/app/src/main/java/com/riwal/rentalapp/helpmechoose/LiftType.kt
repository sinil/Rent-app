package com.riwal.rentalapp.helpmechoose

enum class LiftType {
    NOT_SPECIFIED,
    PEOPLE,
    MATERIALS
}
