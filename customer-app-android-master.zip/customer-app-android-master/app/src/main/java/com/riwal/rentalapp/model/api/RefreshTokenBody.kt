package com.riwal.rentalapp.model.api

class RefreshTokenBody(val refresh_token: String?)