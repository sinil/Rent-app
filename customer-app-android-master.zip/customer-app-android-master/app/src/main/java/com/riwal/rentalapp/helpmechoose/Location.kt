package com.riwal.rentalapp.helpmechoose

enum class Location {
    NOT_SPECIFIED,
    OUTDOORS,
    INDOORS
}
