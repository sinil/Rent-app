package com.riwal.rentalapp.scanmachineqrcode

enum class ScanMachineQRCodeError {
    InvalidQRCode,
    RentalNotFound
}