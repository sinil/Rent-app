package com.riwal.rentalapp.common.extensions.core

fun <T> T.toSingletonList() = listOf(this)