package com.riwal.rentalapp.model

data class Accessory(val name: String, val imageUrl: String?, val quantities: List<Int>?)